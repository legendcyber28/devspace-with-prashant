import React,{useEffect,useRef,useState} from 'react';
import{createRoot}from'react-dom/client';
import{createAvatar}from'@bible-strong/avatar-react';
import artwork from './lime-blob.avatar.json';
import lines from './lines.json';
import clips from './clips.json';
import css from './guide.css';
const sheet=document.createElement('style');sheet.textContent=css;document.head.appendChild(sheet);
const Blob=createAvatar(artwork);
const base=new URL('.',document.currentScript?.src||new URL('creator-guide.js',location.href));
const admin=location.pathname.endsWith('admin.html');
function context(){
 if(!admin)return 'creator_home';
 const app=document.getElementById('app');
 if(!app||app.classList.contains('hide'))return document.getElementById('signinBtn')?.textContent.includes('Sheet')?'creator_picker':'creator_signin';
 return {sugg:'creator_suggestions',charts:'creator_charts',ideas:'creator_ideas',plan:'creator_plan',links:'creator_links'}[document.querySelector('#nav button.on')?.dataset.tab]||'creator_suggestions';
}
function Guide(){
 const[key,setKey]=useState(context),[muted,setMuted]=useState(()=>localStorage.getItem('ds-guide-muted')==='true');
 const audio=useRef(null),unlocked=useRef(false),current=useRef(key),muteRef=useRef(muted),avatar=useRef(null);
 function stop(){if(audio.current){audio.current.pause();audio.current.currentTime=0;audio.current=null;}}
 function play(k){stop();if(muteRef.current||!unlocked.current)return;const a=new Audio(clips[k]);audio.current=a;void a.play().catch(()=>{});}
 useEffect(()=>{current.current=key;avatar.current?.poke('bounce',1);play(key);return stop;},[key]);
 useEffect(()=>{muteRef.current=muted;localStorage.setItem('ds-guide-muted',String(muted));if(muted)stop();},[muted]);
 useEffect(()=>{
  function gesture(){if(!unlocked.current){unlocked.current=true;play(current.current);}}
  function clicked(e){if(e.target.closest('#ds-guide-root'))return;if(!admin){if(e.target.closest('#suggestForm'))setKey('creator_suggest');if(e.target.closest('.plhead'))setKey('creator_playlists');}else setTimeout(()=>setKey(context()),0);}
  document.addEventListener('pointerdown',gesture,{once:true});document.addEventListener('keydown',gesture,{once:true});document.addEventListener('click',clicked);
  const target=admin?document.getElementById('app'):document.getElementById('thanks');
  const gate=admin?document.getElementById('gate'):null;
  const obs=new MutationObserver(()=>{if(admin)setKey(context());else if(target&&getComputedStyle(target).display!=='none')setKey('creator_sent');});
  if(target)obs.observe(target,{attributes:true,subtree:admin,attributeFilter:['class','style']});if(gate)obs.observe(gate,{childList:true,subtree:true,characterData:true});
  return()=>{obs.disconnect();stop();document.removeEventListener('click',clicked);document.removeEventListener('pointerdown',gesture);document.removeEventListener('keydown',gesture);};
 },[]);
 return <aside className="ds-guide" aria-label="Page guide"><div className="ds-guide-art" aria-hidden="true"><Blob ref={avatar} size={82} state="idle" followPointer/></div><div className="ds-guide-content"><p className="ds-guide-bubble" aria-live="polite">{lines[key]}</p><div className="ds-guide-controls"><button type="button" aria-pressed={!muted} onClick={()=>{unlocked.current=true;muteRef.current=!muted;setMuted(!muted);if(muted)play(current.current);}}>Voice {muted?'off':'on'}</button><button type="button" onClick={()=>{unlocked.current=true;play(current.current);}}>Replay guide</button></div></div></aside>;
}
const root=document.createElement('div');root.id='ds-guide-root';
const anchor=admin?document.getElementById('gate'):document.querySelector('header');
if(admin)anchor.before(root);else if(anchor)anchor.after(root);else document.body.prepend(root);
createRoot(root).render(<Guide/>);
