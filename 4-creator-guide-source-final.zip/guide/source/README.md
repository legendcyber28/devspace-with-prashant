Page guide source

Run npm ci in this folder, then use esbuild to bundle guide.jsx into ../guide.js. The CSS is emitted alongside the bundle. Recorded clips live in ../clips and are keyed by lines.json. The guide reads only visible navigation state, never topic bodies, names or account data.

Original avatar art supplied for this app. Runtime license notices are in the parent guide folder.
